<?php

namespace App\Interfaces;

interface IDashboardService
{
    public function getSummery($summeryType);

}
